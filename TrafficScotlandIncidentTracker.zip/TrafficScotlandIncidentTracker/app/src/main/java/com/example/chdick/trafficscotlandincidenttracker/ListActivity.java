package com.example.chdick.trafficscotlandincidenttracker;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chdick on 23/02/2018.
 */

public class ListActivity extends AppCompatActivity
{

    private ListView lv;
    private ArrayList<String> titles;
    private TextView emptyList;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //get incident list from bundle
        setContentView(R.layout.list_activity);
        emptyList = findViewById(R.id.emptyListText);
        titles = new ArrayList<String>();
        final List<Integer> dTypes = new ArrayList<Integer>();
        Bundle bi = getIntent().getBundleExtra("incidents");

        final ArrayList<Incident> incidentList = bi.getParcelableArrayList("incidents");

        //get incident titles from list to be display

        lv = findViewById(R.id.laListView);
        lv.setEmptyView(emptyList);

        if (incidentList != null)
        {
            for (Incident i : incidentList)
            {
                titles.add(i.getTitle());
                dTypes.add(i.getDurationType());
            }

            ArrayAdapter<String> titleAA = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, titles)
            {
                @Override
                public View getView(int pos, View convertView, ViewGroup parent)
                {
                    View itemView = super.getView(pos,convertView,parent);
                    if (dTypes.get(pos) == 3)
                        itemView.setBackgroundColor(getResources().getColor(R.color.paleRed2));
                    else if (dTypes.get(pos) == 2)
                        itemView.setBackgroundColor(getResources().getColor(R.color.paleAmber));
                    else if (dTypes.get(pos) == 1)
                        itemView.setBackgroundColor(getResources().getColor(R.color.paleGreen));
                    else
                        itemView.setBackgroundColor(Color.WHITE);

                    return itemView;
                }
            };

            lv.setAdapter(titleAA);

            //On list item click, bundle incident position in array
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
            {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id)
                {
                    Intent incidentIntent = new Intent(ListActivity.this, IncidentActivity.class);
                    Bundle incidentsBundle = new Bundle();
                    incidentsBundle.putParcelable("incident",incidentList.get(pos));
                    incidentIntent.putExtra("incidents",incidentsBundle);
                    startActivity(incidentIntent);
                }
            });
        }
    }
}