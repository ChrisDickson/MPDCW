package com.example.chdick.trafficscotlandincidenttracker;

import android.content.Intent;
import android.icu.util.DateInterval;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    private static final int MSPERDAY = (24 * 60 * 60 * 1000);
    private String urlCI="https://trafficscotland.org/rss/feeds/currentincidents.aspx";
    private String urlPR="https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private TextView incidentTitle;
    private Button ciButton;
    private Button prButton;
    private String result = "";
    private LinearLayout ll;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ll = new LinearLayout((getApplicationContext()));
        ll.setOrientation(LinearLayout.VERTICAL);

        incidentTitle = findViewById(R.id.incidentTitle);
        ciButton = findViewById(R.id.currentIncidentsButton);
        prButton = findViewById(R.id.plannedRoadworksButton);

        ciButton.setOnClickListener(this);
        prButton.setOnClickListener(this);

    }

    public void onClick(View view)
    {
        //Passes appropriate URL to task started based on button clicked
        if (view == ciButton)
            view(urlCI);

        if (view == prButton)
        {
            view(urlPR);
        }
    }

    public void view(String url)
    {
        new Thread(new Task(url)).start();
    }

    class Task implements Runnable
    {
        private String url1;
        Incident incident = null;
        ArrayList<Incident> incidents = null;

        public Task (String aUrl)
        {
            url1 = aUrl;
        }

        @Override
        public void run()
        {
            String inputLine;
            try
            {
                //Created PullParser, and required instances for XMLPP
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                URL url = new URL(url1);
                URLConnection uc = url.openConnection();
                InputStreamReader isr = new InputStreamReader(uc.getInputStream());
                BufferedReader in = new BufferedReader(isr);

                //lineNum used to skip first line (NOT FIRST TWO)
                int lineNum = 0;

                //Used to assign each incident an ID #
                int idCount = 0;

                while ((inputLine = in.readLine()) != null)
                {
                    lineNum++;
                    if (lineNum > 1)
                    {
                        result = result + inputLine;
                    }
                }


                //introduces input to parser
                xpp.setInput(new StringReader(result));

                //While not at the end of input,
                //carry out different tasks based on current eventType
                int eventType = xpp.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    switch (eventType)
                    {
                        case XmlPullParser.START_TAG:
                            String tag = xpp.getName();
                            //<channel> tags used in XML input to contain all incidents

                            if (tag.equalsIgnoreCase("channel"))
                                incidents = new ArrayList<Incident>();

                            //item tags contain incident data
                            if (tag.equalsIgnoreCase("item")) {
                                incident = new Incident();
                                incidents.add(incident);
                            }

                            //for current incident, get all data
                            if (tag.equalsIgnoreCase("title") && incident != null)
                                incident.setTitle(xpp.nextText());

                            if (tag.equalsIgnoreCase("description") && incident != null)
                                incident.setDescription(xpp.nextText());

                            if (tag.equalsIgnoreCase("link") && incident != null)
                                incident.setLink(xpp.nextText());

                            if (tag.equalsIgnoreCase("point") && incident != null)
                                incident.setGeopoint(xpp.nextText());

                            if (tag.equalsIgnoreCase("pubdate") && incident != null)
                                incident.setPubdate(xpp.nextText());
                            break;

                        //At end of tag, if item set id and add to array list
                        case XmlPullParser.END_TAG:
                            if (xpp.getName().equalsIgnoreCase("item"))
                            {
                                incident.setId(idCount);
                                idCount++;

                                List<String> allMatches = new ArrayList<String>();
                                Matcher m = Pattern.compile("([\\d]{2}) ([a-zA-Z]+) ([\\d]{4})")
                                        .matcher(incident.getDescription());
                                while (m.find())
                                {
                                    allMatches.add(m.group(0));
                                }

                                if (allMatches.size() > 0)
                                {
                                    SimpleDateFormat formatter = new SimpleDateFormat("dd MMMMMMMMMMMMMMMMMM yyyy", Locale.UK);
                                    List<Date> allDates = new ArrayList<Date>();
                                    for (String s : allMatches)
                                    {

                                        try
                                        {
                                            Date d = formatter.parse(s);
                                            allDates.add(d);
                                        }
                                        catch (ParseException e)
                                        {
                                            e.printStackTrace();
                                        }
                                    }
                                    Date startDate = allDates.get(0);
                                    Date endDate = allDates.get(1);

                                    long diff = endDate.getTime() - startDate.getTime();
                                    incident.setDuration(diff);
                                    long days = diff / MSPERDAY;

                                    //dType controls colour of list item
                                    //0 is < 1 week, green
                                    //1 is between 1 week and 1 month, amber
                                    //2 is more than a month, red
                                    int dType = 1;
                                    if (days > 30 )
                                        dType = 3;
                                    else if (days > 7)
                                        dType = 2;

                                    incident.setDurationType(dType);
                                }

                            }
                            break;
                    }
                    eventType = xpp.next();
                }
            }
            catch (XmlPullParserException xppe)
            {
                Log.e("MyTag", "XPPE: "+xppe.toString());
            }
            catch (IOException ioe)
            {
                Log.e("MyTag", "IOE"+ioe.toString());
            }
            //put incident list in bundle and pass to new activity to display
            Intent listIntent = new Intent(MainActivity.this, ListActivity.class);
            Bundle incidentsBundle = new Bundle();
            incidentsBundle.putParcelableArrayList("incidents",incidents);
            listIntent.putExtra("incidents",incidentsBundle);
            startActivity(listIntent);
        }
    }
}