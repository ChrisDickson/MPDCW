package com.example.chdick.trafficscotlandincidenttracker;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by chdick on 13/02/2018.
 * Christopher Dickson
 * S1221706
 */

public class Incident implements Parcelable {

    private String title;
    private String description;
    private String link;
    private String geopoint;
    private String author;
    private String comments;
    private String pubdate;
    private int id;
    private long duration;
    private int durationType;

    public Incident(Parcel source) {
        title = source.readString();
        description = source.readString();
        link = source.readString();
        geopoint = source.readString();
        author = source.readString();
        comments = source.readString();
        pubdate = source.readString();
        id = source.readInt();
        duration = source.readLong();
        durationType = source.readInt();
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getGeopoint() {
        return geopoint;
    }

    public void setGeopoint(String geopoint) {
        this.geopoint = geopoint;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    public String toString()
    {
        return this.title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public int getDurationType() {return durationType;}

    public void setDurationType(int durationType) { this.durationType = durationType;}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeString(description);
        parcel.writeString(link);
        parcel.writeString(geopoint);
        parcel.writeString(author);
        parcel.writeString(comments);
        parcel.writeString(pubdate);
        parcel.writeInt(id);
        parcel.writeLong(duration);
        parcel.writeInt(durationType);

    }

    public Incident()
    {

    }

    public Incident (int id, String title, String description, String link, String geopoint,
                     String author, String comments, String pubdate, long duration, int durationType)
    {
        this.title = title;
        this.description = description;
        this.link = link;
        this.geopoint = geopoint;
        this.author = author;
        this.comments = comments;
        this.pubdate = pubdate;
        this.id = id;
        this.duration = duration;
        this.durationType = durationType;
    }

    public static final Parcelable.Creator<Incident> CREATOR = new Parcelable.Creator<Incident>()
    {
        @Override
        public Incident createFromParcel(Parcel source)
        {
            return new Incident(source);
        }

        @Override
        public Incident[] newArray(int i)
        {
            return new Incident[i];
        }
    };
}


