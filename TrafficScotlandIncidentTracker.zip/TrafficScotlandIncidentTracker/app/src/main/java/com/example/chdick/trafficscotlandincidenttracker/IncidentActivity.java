package com.example.chdick.trafficscotlandincidenttracker;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by chdick on 26/02/2018.
 *  * Christopher Dickson
 * S1221706
 */

public class IncidentActivity extends AppCompatActivity implements OnMapReadyCallback
{
    private TextView incidentTitle;
    private TextView incidentDesc;
    private TextView incidentPubD;
    private float[] floatLatLong;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.incident_layout);
        Bundle bi = getIntent().getBundleExtra("incidents");
        Incident incident = bi.getParcelable("incident");

        incidentTitle = findViewById(R.id.incidentTitle);

        incidentTitle.setText(incident.getTitle());
        incidentDesc = findViewById(R.id.incidentDesc);
        incidentPubD = findViewById(R.id.incidentPubD);


        incidentPubD.setText("S1221706"+"\nPublished: "+incident.getPubdate());

        String iDesc = incident.getDescription();
        iDesc = iDesc.replaceAll("<(.*?)\\>"," \n");//Replaces HTML with new line
        iDesc = iDesc.replaceAll("Traffic Management:",
                "\nTraffic Management:");
        iDesc = iDesc.replaceAll("Diversion Information",
                "\nDiversion Information");
        incidentDesc.setText(iDesc);

        String coords = incident.getGeopoint();
        String[] stringLatLong = coords.split(" ");

        floatLatLong = new float[stringLatLong.length];

        for (int e = 0; e < stringLatLong.length; e++)
        {
            floatLatLong[e] = Float.parseFloat(stringLatLong[e]);
        }


        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.incidentMap);

        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        LatLng incidentLocation = new LatLng(floatLatLong[0],floatLatLong[1]);
        googleMap.addMarker((
                new MarkerOptions().position(incidentLocation).title("Incident Location")));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(incidentLocation,12.0f));
    }
}

